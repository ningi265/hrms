const Invoice = require("../models/Invoice");
const PurchaseOrder = require("../models/PurchaseOrder");
const { notifyInvoiceSubmitted, notifyInvoiceApproval, notifyInvoicePayment } = require("../services/notificationService");

// Vendor submits an invoice
exports.submitInvoice = async (req, res) => {
    try {
        const { poId, invoiceNumber, amountDue } = req.body;
        const po = await PurchaseOrder.findById(poId);

        if (!po) return res.status(404).json({ message: "Purchase Order not found" });
        if (po.vendor.toString() !== req.user.id) return res.status(403).json({ message: "Unauthorized" });

        const existingInvoice = await Invoice.findOne({ invoiceNumber });
        if (existingInvoice) return res.status(400).json({ message: "Invoice number already exists" });

        const invoice = await Invoice.create({
            po: po._id,
            vendor: po.vendor,
            amountDue,
            invoiceNumber
        });

        await notifyInvoiceSubmitted(po.procurementOfficer, invoice);

        res.status(201).json({ message: "Invoice submitted successfully", invoice });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Approve an invoice (Admin Only)
exports.approveInvoice = async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id);
        if (!invoice) return res.status(404).json({ message: "Invoice not found" });

        invoice.status = "approved";
        invoice.approver = req.user.id;
        await invoice.save();

        await notifyInvoiceApproval(invoice.vendor, invoice);

        res.json({ message: "Invoice approved", invoice });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Reject an invoice (Admin Only)
exports.rejectInvoice = async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id);
        if (!invoice) return res.status(404).json({ message: "Invoice not found" });

        invoice.status = "rejected";
        invoice.approver = req.user.id;
        await invoice.save();

        res.json({ message: "Invoice rejected", invoice });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Mark invoice as paid (Finance team)
exports.markAsPaid = async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id);
        if (!invoice) return res.status(404).json({ message: "Invoice not found" });

        if (invoice.status !== "approved") return res.status(400).json({ message: "Only approved invoices can be paid" });

        invoice.status = "paid";
        invoice.paymentDate = new Date();
        await invoice.save();

        await notifyInvoicePayment(invoice.vendor, invoice);

        res.json({ message: "Invoice marked as paid", invoice });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get all invoices
exports.getAllInvoices = async (req, res) => {
    try {
        const invoices = await Invoice.find().populate("po vendor approver", "name email");
        res.json(invoices);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get a single invoice
exports.getInvoiceById = async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id).populate("po vendor approver", "name email");
        if (!invoice) return res.status(404).json({ message: "Invoice not found" });

        res.json(invoice);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};
