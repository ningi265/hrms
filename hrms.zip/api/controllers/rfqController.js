const RFQ = require("../../models/RFQ");
const Vendor = require("../../models/vendor");
const { notifyVendorsAboutRFQ, notifySelectedVendor } = require("../services/notificationService");

// Create RFQ (Only Procurement Officers)
exports.createRFQ = async (req, res) => {
    try {
        const { vendors, itemName, quantity } = req.body;

        const rfq = await RFQ.create({
            procurementOfficer: req.user.id,
            vendors,
            itemName,
            quantity
        });

        // Notify vendors about the RFQ
        await notifyVendorsAboutRFQ(vendors, rfq);

        res.status(201).json({ message: "RFQ created successfully and vendors notified", rfq });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get all RFQs (Procurement Officers & Admins)
exports.getAllRFQs = async (req, res) => {
    try {
        const rfqs = await RFQ.find().populate("vendors procurementOfficer", "name email");
        res.json(rfqs);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Vendors submit quotes for RFQ
exports.submitQuote = async (req, res) => {
    try {
        const { price, deliveryTime, notes } = req.body;
        const rfq = await RFQ.findById(req.params.id);

        if (!rfq || rfq.status === "closed") return res.status(400).json({ message: "RFQ not found or closed" });

        // Ensure vendor is part of the RFQ process
        if (!rfq.vendors.includes(req.user.id)) {
            return res.status(403).json({ message: "You are not invited to submit a quote for this RFQ." });
        }

        rfq.quotes.push({ vendor: req.user.id, price, deliveryTime, notes });
        await rfq.save();

        res.json({ message: "Quote submitted successfully", rfq });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Select the best vendor based on lowest price or other criteria
exports.selectVendor = async (req, res) => {
    try {
        const rfq = await RFQ.findById(req.params.id).populate("quotes.vendor");

        if (!rfq) return res.status(404).json({ message: "RFQ not found" });
        if (rfq.status === "closed") return res.status(400).json({ message: "RFQ is already closed" });
        if (rfq.quotes.length === 0) return res.status(400).json({ message: "No quotes available" });

        // Select vendor with the lowest price
        const bestQuote = rfq.quotes.reduce((prev, curr) => (prev.price < curr.price ? prev : curr));

        rfq.status = "closed";
        rfq.selectedVendor = bestQuote.vendor;
        await rfq.save();

        // Notify the selected vendor
        await notifySelectedVendor(bestQuote.vendor._id, rfq);

        res.json({ message: `Vendor ${bestQuote.vendor.name} selected and notified`, bestQuote });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

