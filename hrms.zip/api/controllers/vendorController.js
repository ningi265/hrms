const Vendor = require("../../models/vendor");

// Add a new vendor
exports.addVendor = async (req, res) => {
    try {
        const { name, email, phone, address, categories } = req.body;

        const vendor = await Vendor.create({ name, email, phone, address, categories });
        res.status(201).json({ message: "Vendor added successfully", vendor });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get all vendors
exports.getVendors = async (req, res) => {
    try {
        const vendors = await Vendor.find();
        res.json(vendors);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Update a vendor
exports.updateVendor = async (req, res) => {
    try {
        const vendor = await Vendor.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!vendor) return res.status(404).json({ message: "Vendor not found" });

        res.json({ message: "Vendor updated", vendor });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Delete a vendor
exports.deleteVendor = async (req, res) => {
    try {
        await Vendor.findByIdAndDelete(req.params.id);
        res.json({ message: "Vendor deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};
