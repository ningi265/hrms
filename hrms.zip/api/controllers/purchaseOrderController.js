const PurchaseOrder = require("../../models/purchaseOrder");
const RFQ = require("../../models/RFQ");
const { notifyVendorPOCreated, notifyPOApproval,notifyPOShipped, notifyPODelivered, notifyPOConfirmed } = require("../services/notificationService");

// Create a PO (Procurement Officer)
exports.createPO = async (req, res) => {
    try {
        const { rfqId, items } = req.body;
        const rfq = await RFQ.findById(rfqId).populate("selectedVendor");

        if (!rfq) return res.status(404).json({ message: "RFQ not found" });
        if (rfq.status !== "closed") return res.status(400).json({ message: "RFQ must be closed to generate a PO" });

        const totalAmount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        const po = await PurchaseOrder.create({
            rfq: rfq._id,
            vendor: rfq.selectedVendor,
            procurementOfficer: req.user.id,
            items,
            totalAmount
        });

        // Notify the vendor
        await notifyVendorPOCreated(rfq.selectedVendor, po);

        res.status(201).json({ message: "Purchase Order created successfully", po });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Approve a PO (Admin Only)
exports.approvePO = async (req, res) => {
    try {
        const po = await PurchaseOrder.findById(req.params.id);
        if (!po) return res.status(404).json({ message: "Purchase Order not found" });

        po.status = "approved";
        po.approver = req.user.id;
        await po.save();

        // Notify procurement officer and vendor
        await notifyPOApproval(po.procurementOfficer, po.vendor, po);

        res.json({ message: "Purchase Order approved", po });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Reject a PO (Admin Only)
exports.rejectPO = async (req, res) => {
    try {
        const po = await PurchaseOrder.findById(req.params.id);
        if (!po) return res.status(404).json({ message: "Purchase Order not found" });

        po.status = "rejected";
        po.approver = req.user.id;
        await po.save();

        res.json({ message: "Purchase Order rejected", po });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get All POs (Admin & Procurement Officers)
exports.getAllPOs = async (req, res) => {
    try {
        const pos = await PurchaseOrder.find().populate("vendor procurementOfficer approver", "name email");
        res.json(pos);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Get a Single PO
exports.getPOById = async (req, res) => {
    try {
        const po = await PurchaseOrder.findById(req.params.id).populate("vendor procurementOfficer approver", "name email");
        if (!po) return res.status(404).json({ message: "Purchase Order not found" });

        res.json(po);
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};


// Vendor updates PO delivery status
exports.updateDeliveryStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const po = await PurchaseOrder.findById(req.params.id);

        if (!po) return res.status(404).json({ message: "Purchase Order not found" });
        if (po.vendor.toString() !== req.user.id) return res.status(403).json({ message: "Unauthorized" });

        if (!["shipped", "delivered"].includes(status)) return res.status(400).json({ message: "Invalid status" });

        po.deliveryStatus = status;
        await po.save();

        if (status === "shipped") {
            await notifyPOShipped(po.procurementOfficer, po);
        } else if (status === "delivered") {
            await notifyPODelivered(po.procurementOfficer, po);
        }

        res.json({ message: `PO marked as ${status}`, po });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Procurement officer confirms delivery
exports.confirmDelivery = async (req, res) => {
    try {
        const po = await PurchaseOrder.findById(req.params.id);

        if (!po) return res.status(404).json({ message: "Purchase Order not found" });
        if (po.procurementOfficer.toString() !== req.user.id) return res.status(403).json({ message: "Unauthorized" });

        if (po.deliveryStatus !== "delivered") return res.status(400).json({ message: "PO is not yet delivered" });

        po.deliveryStatus = "confirmed";
        await po.save();

        await notifyPOConfirmed(po.vendor, po);

        res.json({ message: "Delivery confirmed", po });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

