const express = require("express");
const {
    submitInvoice,
    approveInvoice,
    rejectInvoice,
    markAsPaid,
    getAllInvoices,
    getInvoiceById
} = require("../controllers/invoiceController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

// Vendor submits an invoice
router.post("/", protect(["vendor"]), submitInvoice);

// Approve invoice (Admin Only)
router.put("/:id/approve", protect(["admin"]), approveInvoice);

// Reject invoice (Admin Only)
router.put("/:id/reject", protect(["admin"]), rejectInvoice);

// Mark invoice as paid (Finance Team)
router.put("/:id/pay", protect(["finance", "admin"]), markAsPaid);

// Get all invoices
router.get("/", protect(["procurement_officer", "admin", "finance"]), getAllInvoices);

// Get single invoice
router.get("/:id", protect(["procurement_officer", "admin", "finance", "vendor"]), getInvoiceById);

module.exports = router;
