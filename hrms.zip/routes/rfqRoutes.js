const express = require("express");
const {
    createRFQ,
    getAllRFQs,
    submitQuote,
    selectVendor
} = require("../api/controllers/rfqController");
const { protect } = require("../api/middleware/authMiddleware");

const router = express.Router();

// Create RFQ (Procurement Officers only)
router.post("/", protect(["procurement_officer", "admin"]), createRFQ);

// Get all RFQs (Procurement Officers & Admins)
router.get("/", protect(["procurement_officer", "admin"]), getAllRFQs);

// Vendor submits a quote
router.post("/:id/quote", protect(["vendor"]), submitQuote);

// Select the best vendor (Procurement Officers & Admins)
router.put("/:id/select", protect(["procurement_officer", "admin"]), selectVendor);

module.exports = router;
